/**
 * @param {number} length
 * @return {Array}
 */
const range = length => Array.apply(null, { length })

export default range
